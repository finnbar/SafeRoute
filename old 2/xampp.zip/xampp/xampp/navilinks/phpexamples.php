<a class="n" target="content" onclick="h(this);" href="phpinfo.php">phpinfo()</a><br>
<a class="n" target="content" onclick="h(this);" href="cds.php"><?php echo $TEXT['navi-cdcol']; ?></a><br>
<a class="n" target="content" onclick="h(this);" href="biorhythm.php"><?php echo $TEXT['navi-bio']; ?></a><br>
<a class="n" target="content" onclick="h(this);" href="iart.php"><?php echo $TEXT['navi-iart']; ?></a><br>
<a class="n" target="content" onclick="h(this);" href="phonebook.php"><?php echo $TEXT['navi-phonebook']; ?></a><br>